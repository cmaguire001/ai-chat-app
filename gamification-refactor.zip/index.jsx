/**
 * pages/index.jsx
 * ─────────────────────────────────────────────────────────────
 * Thin orchestration layer. This file should contain:
 *  - Local UI state only (messages, loading, theme, badge panel open)
 *  - API call logic
 *  - Layout / composition
 *
 * Game logic lives entirely in useGameStats().
 * Theme unlock logic lives in ThemeSelector.
 * All gamification UI is imported as display-only components.
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import Bubbles from '../components/Bubbles';
import UnderwaterAudio, { playMessageSend, playReply } from '../components/UnderwaterAudio';
import ThemeSelector from '../components/ThemeSelector';

import {
  useGameStats,
  CoinBar,
  CoinBurst,
  BadgeButton,
  BadgePanel,
  BadgeToast,
  FARMER_THEME_UNLOCK_AT,
} from '../components/Gamification';

// ─── Sub-components ───────────────────────────────────────────

function Message({ msg }) {
  const isUser = msg.role === 'user';
  return (
    <div style={{
      display: 'flex',
      justifyContent: isUser ? 'flex-end' : 'flex-start',
      marginBottom: '12px',
    }}>
      <div style={{
        maxWidth: '75%',
        padding: '10px 14px',
        borderRadius: isUser ? '18px 18px 4px 18px' : '18px 18px 18px 4px',
        background: isUser ? 'var(--accent)' : 'var(--surface2)',
        color: isUser ? '#fff' : 'var(--text)',
        border: isUser ? 'none' : '1px solid var(--border)',
        fontSize: '14px',
        lineHeight: 1.5,
        wordBreak: 'break-word',
      }}>
        {msg.content}
      </div>
    </div>
  );
}

function TypingDots() {
  return (
    <div style={{
      display: 'flex',
      gap: '4px',
      padding: '10px 14px',
      background: 'var(--surface2)',
      borderRadius: '18px 18px 18px 4px',
      width: 'fit-content',
      marginBottom: '12px',
    }}>
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          style={{
            width: '7px', height: '7px',
            borderRadius: '50%',
            background: 'var(--text-muted)',
            animation: 'pulse 1.5s ease-in-out infinite',
            animationDelay: `${i * 0.2}s`,
          }}
        />
      ))}
    </div>
  );
}

// ─── Farmer theme styles ──────────────────────────────────────
// Injected globally so CSS variables work across all children.

const FARMER_THEME_CSS = `
  .theme-farmer {
    --bg:         #f5ead0;
    --surface:    #fdf6e3;
    --surface2:   #f0e6c8;
    --border:     #c8a96e;
    --text:       #3b2a14;
    --text-muted: #7a5c30;
    --accent:     #6aab2e;
    --input-bg:   #fdf6e3;
  }

  .theme-farmer .theme-btn {
    background: #f0e0a0;
    color: #3b2a14;
    border: 1.5px solid #c8a96e;
  }

  .theme-farmer .theme-btn:hover,
  .theme-farmer .theme-btn.active {
    background: #6aab2e;
    color: #fff;
    border-color: #4e8a1e;
  }

  /* Sunflower cursor easter egg */
  .theme-farmer * {
    cursor: url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='32' height='32' viewBox='0 0 32 32'><text y='26' font-size='26'>🌻</text></svg>") 16 16, auto;
  }
`;

// ─── Home ─────────────────────────────────────────────────────

const INITIAL_MESSAGES = [
  { role: 'assistant', content: "Hey! 👋 I'm your AI assistant. Ask me anything and earn coins! 🪙" },
];

const THEME_STORAGE_KEY = 'chat-theme';

export default function Home() {
  // ── UI state ──────────────────────────────────────────────
  const [theme, setThemeRaw]       = useState('light');
  const [badgePanelOpen, setBadgePanelOpen] = useState(false);
  const [messages, setMessages]    = useState(INITIAL_MESSAGES);
  const [isLoading, setIsLoading]  = useState(false);

  // ── Refs ──────────────────────────────────────────────────
  const bottomRef   = useRef(null);
  const textareaRef = useRef(null);

  // ── Game state (all logic inside hook) ───────────────────
  const { stats, multiplier, coinBurst, badgeToast, onMessageSent } = useGameStats();

  // ── Theme persistence ─────────────────────────────────────
  useEffect(() => {
    const saved = localStorage.getItem(THEME_STORAGE_KEY);
    if (saved) setThemeRaw(saved);
  }, []);

  const setTheme = useCallback((t) => {
    // Guard: don't allow switching to farmer unless unlocked
    const isLockedFarmer = t === 'farmer' && stats.totalMessages < FARMER_THEME_UNLOCK_AT;
    if (isLockedFarmer) return;
    setThemeRaw(t);
    localStorage.setItem(THEME_STORAGE_KEY, t);
  }, [stats.totalMessages]);

  // ── Auto-unlock farmer theme ──────────────────────────────
  // When user hits the threshold, auto-notify but don't auto-switch.
  const prevMessageCount = useRef(stats.totalMessages);
  useEffect(() => {
    if (
      prevMessageCount.current < FARMER_THEME_UNLOCK_AT &&
      stats.totalMessages >= FARMER_THEME_UNLOCK_AT
    ) {
      // Could show a toast here — for now ThemeSelector reflects it visually
    }
    prevMessageCount.current = stats.totalMessages;
  }, [stats.totalMessages]);

  // ── Scroll to bottom on new message ──────────────────────
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // ── Send message ──────────────────────────────────────────
  const sendMessage = useCallback(async () => {
    const text = textareaRef.current?.value?.trim();
    if (!text || isLoading) return;

    if (theme === 'underwater') playMessageSend();

    const newMessages = [...messages, { role: 'user', content: text }];
    setMessages(newMessages);
    if (textareaRef.current) textareaRef.current.value = '';
    setIsLoading(true);

    // Award coins — all logic inside the hook
    onMessageSent();

    try {
      const res  = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: newMessages }),
      });
      const data = await res.json();
      if (theme === 'underwater') playReply();
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: data.reply || data.error || 'Something went wrong.' },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'Network error. Please try again.' },
      ]);
    } finally {
      setIsLoading(false);
    }
  }, [messages, isLoading, theme, onMessageSent]);

  const handleKeyDown = useCallback((e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }, [sendMessage]);

  // ── Derived ───────────────────────────────────────────────
  const isUnderwater = theme === 'underwater';
  const isFarmer     = theme === 'farmer';
  const blurSurface  = isUnderwater ? 'blur(12px)' : 'none';

  return (
    <div
      className={`theme-${theme}${isUnderwater ? ' underwater-bg' : ''}`}
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '16px',
        background: isFarmer
          ? 'radial-gradient(ellipse at top, #e8f5a3 0%, #f5ead0 60%, #d4b483 100%)'
          : 'var(--bg)',
      }}
    >
      {/* Inject farmer CSS */}
      {isFarmer && <style>{FARMER_THEME_CSS}</style>}

      {/* Underwater layer */}
      {isUnderwater && <Bubbles />}
      {isUnderwater && <UnderwaterAudio active={isUnderwater} />}

      {/* ── Overlay layer — rendered at root to escape backdrop-filter ── */}
      <CoinBurst
        coins={coinBurst.amount}
        visible={coinBurst.visible}
        multiplier={multiplier}
      />
      <BadgeToast badge={badgeToast.badge} visible={badgeToast.visible} />
      <BadgePanel
        stats={stats}
        open={badgePanelOpen}
        onClose={() => setBadgePanelOpen(false)}
      />

      {/* ── Chat shell ── */}
      <div style={{
        width: '100%',
        maxWidth: '680px',
        height: 'min(720px, 92vh)',
        display: 'flex',
        flexDirection: 'column',
        position: 'relative',
        // No z-index here — that's what was trapping fixed children before
      }}>

        {/* Header */}
        <div style={{
          background: 'var(--surface)',
          borderBottom: '1px solid var(--border)',
          padding: '16px 20px',
          borderRadius: '16px 16px 0 0',
          backdropFilter: isUnderwater ? 'blur(16px)' : 'none',
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
            {/* Logo */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{
                width: '36px', height: '36px',
                borderRadius: '10px',
                background: 'var(--accent)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '18px',
              }}>
                {isUnderwater ? '🐠' : isFarmer ? '🚜' : '✦'}
              </div>
              <div>
                <div style={{ fontWeight: 'bold', color: 'var(--text)', fontSize: '15px' }}>
                  AI Chat
                </div>
                <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
                  {isUnderwater
                    ? 'Deep sea edition 🌊'
                    : isFarmer
                    ? 'Down on the farm 🌾'
                    : 'Powered by Llama'}
                </div>
              </div>
            </div>

            {/* Controls — BadgeButton inline with ThemeSelector */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <BadgeButton
                stats={stats}
                onClick={() => setBadgePanelOpen((o) => !o)}
              />
              <ThemeSelector
                theme={theme}
                setTheme={setTheme}
                totalMessages={stats.totalMessages}
              />
            </div>
          </div>
        </div>

        {/* Messages */}
        <div style={{
          flex: 1,
          overflowY: 'auto',
          padding: '16px',
          background: isUnderwater
            ? 'rgba(0,15,40,0.6)'
            : isFarmer
            ? 'rgba(253,246,227,0.85)'
            : 'var(--surface)',
          backdropFilter: blurSurface,
        }}>
          {messages.map((msg, i) => <Message key={i} msg={msg} />)}
          {isLoading && <TypingDots />}
          <div ref={bottomRef} />
        </div>

        {/* Coin Bar */}
        <CoinBar totalCoins={stats.totalCoins} multiplier={multiplier} />

        {/* Input */}
        <div style={{
          background: 'var(--surface)',
          borderTop: '1px solid var(--border)',
          padding: '12px 16px',
          borderRadius: '0 0 16px 16px',
          backdropFilter: isUnderwater ? 'blur(16px)' : 'none',
        }}>
          <div style={{ display: 'flex', gap: '8px', alignItems: 'flex-end' }}>
            <textarea
              ref={textareaRef}
              defaultValue=""
              onKeyDown={handleKeyDown}
              rows={1}
              placeholder={
                isUnderwater
                  ? '🐟 Message from the deep…'
                  : isFarmer
                  ? '🌽 What's growin' on?'
                  : 'Send a message… (Enter to send)'
              }
              style={{
                flex: 1,
                minHeight: '44px',
                maxHeight: '120px',
                padding: '10px 14px',
                borderRadius: '12px',
                border: '1.5px solid var(--border)',
                background: 'var(--input-bg)',
                color: 'var(--text)',
                fontSize: '14px',
                resize: 'none',
                fontFamily: 'inherit',
                outline: 'none',
              }}
            />
            <button
              onClick={sendMessage}
              disabled={isLoading}
              style={{
                minHeight: '44px',
                padding: '10px 20px',
                borderRadius: '12px',
                background: 'var(--accent)',
                color: 'white',
                border: 'none',
                cursor: isLoading ? 'not-allowed' : 'pointer',
                fontWeight: 'bold',
                opacity: isLoading ? 0.5 : 1,
                fontSize: '14px',
                transition: 'opacity 0.2s',
              }}
            >
              {isLoading ? '…' : isUnderwater ? '🌊' : isFarmer ? '🌾' : 'Send'}
            </button>
          </div>
          <div style={{
            fontSize: '11px',
            color: 'var(--text-muted)',
            textAlign: 'center',
            marginTop: '6px',
          }}>
            Enter to send · Shift+Enter for new line
          </div>
        </div>

      </div>
    </div>
  );
}
