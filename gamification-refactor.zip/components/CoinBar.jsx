/**
 * CoinBar — replaces XPBar.
 * Pinball-style score display + animated coin stack showing level progress.
 * Pure display component — receives all data via props.
 */

import React, { useState, useEffect } from 'react';
import { SpinningCoin } from './SpinningCoin';
import { getLevelInfo } from '../utils/gamification';
import { MAX_COIN_STACK } from '../constants/gamification';

/** CSS keyframes injected once */
const GLOBAL_STYLES = `
  @keyframes coinSpin {
    0%   { transform: rotateY(0deg)   scaleX(1);    }
    25%  { transform: rotateY(90deg)  scaleX(0.12); }
    50%  { transform: rotateY(180deg) scaleX(1);    }
    75%  { transform: rotateY(270deg) scaleX(0.12); }
    100% { transform: rotateY(360deg) scaleX(1);    }
  }
  @keyframes sparkPop {
    0%   { opacity: 1; transform: translate(0, 0) scale(1.2); }
    100% { opacity: 0; transform: translate(var(--tx), var(--ty)) scale(0); }
  }
  @keyframes multiplierPulse {
    0%, 100% { transform: scale(1);    }
    50%      { transform: scale(1.18); }
  }
  @keyframes scoreCount {
    0%   { opacity: 0.6; }
    100% { opacity: 1;   }
  }
`;

export function CoinBar({ totalCoins = 0, multiplier = 1 }) {
  const { current, next, progress, coinsIntoLevel, coinsNeeded } = getLevelInfo(totalCoins);
  const filled = Math.round((progress / 100) * MAX_COIN_STACK);

  // Animate score ticking up
  const [displayCoins, setDisplayCoins] = useState(totalCoins);
  useEffect(() => {
    if (totalCoins === displayCoins) return;
    const diff  = totalCoins - displayCoins;
    const step  = Math.ceil(diff / 8);
    const timer = setTimeout(() => setDisplayCoins((c) => Math.min(c + step, totalCoins)), 40);
    return () => clearTimeout(timer);
  }, [totalCoins, displayCoins]);

  return (
    <div style={{
      padding: '10px 16px 12px',
      background: 'var(--surface2)',
      borderTop: '1px solid var(--border)',
    }}>
      <style>{GLOBAL_STYLES}</style>

      {/* Row 1 — pinball score + multiplier + level */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '8px',
      }}>
        {/* Score */}
        <div style={{
          fontFamily: '"Courier New", monospace',
          fontSize: '22px',
          fontWeight: 'bold',
          letterSpacing: '3px',
          color: '#ffe566',
          textShadow: '0 0 10px rgba(255,210,0,0.9), 0 0 24px rgba(255,150,0,0.5)',
          animation: totalCoins !== displayCoins ? 'scoreCount 0.1s ease-in-out' : 'none',
        }}>
          {String(displayCoins).padStart(6, '0')}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          {/* Multiplier badge — only shows when active */}
          {multiplier > 1 && (
            <div style={{
              background: 'linear-gradient(135deg, #ff6a00, #ee0979)',
              borderRadius: '6px',
              padding: '2px 8px',
              fontSize: '13px',
              fontWeight: 'bold',
              color: '#fff',
              animation: 'multiplierPulse 0.5s ease-in-out infinite',
              boxShadow: '0 0 14px rgba(255,100,0,0.8)',
              userSelect: 'none',
            }}>
              {multiplier}×
            </div>
          )}

          {/* Level label */}
          <div style={{ fontSize: '11px', color: 'var(--text-muted)', textAlign: 'right' }}>
            <span style={{ color: '#ffe566', fontWeight: 'bold' }}>
              Lv.{current.level}
            </span>
            {' '}{current.name}
          </div>
        </div>
      </div>

      {/* Row 2 — coin stack */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '3px', height: '32px' }}>
        {Array.from({ length: MAX_COIN_STACK }).map((_, i) => (
          <SpinningCoin
            key={i}
            size={26}
            delay={i * 0.11}
            dim={i >= filled}
          />
        ))}
        <span style={{
          marginLeft: '8px',
          fontSize: '10px',
          color: 'var(--text-muted)',
          whiteSpace: 'nowrap',
        }}>
          {next
            ? `${coinsIntoLevel}/${coinsNeeded} → Lv.${next.level}`
            : '✦ MAX LEVEL'}
        </span>
      </div>
    </div>
  );
}
