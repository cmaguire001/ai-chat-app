/**
 * CoinBurst — floating reward notification with spark particles.
 * Pure display component. Visibility controlled by parent.
 */

import React, { useMemo } from 'react';
import { SpinningCoin } from './SpinningCoin';

const SPARK_COUNT = 10;
const SPARK_COLORS = ['#ffffff', '#ffe566', '#ff9900', '#ffcc00'];

function generateSparks() {
  return Array.from({ length: SPARK_COUNT }).map((_, i) => {
    const angle = (i / SPARK_COUNT) * 360;
    const dist  = 28 + Math.random() * 24;
    const size  = i % 2 === 0 ? 7 : 4;
    const color = SPARK_COLORS[i % SPARK_COLORS.length];
    return {
      id: i,
      tx: `${Math.cos((angle * Math.PI) / 180) * dist}px`,
      ty: `${Math.sin((angle * Math.PI) / 180) * dist}px`,
      delay: `${i * 0.04}s`,
      size,
      color,
    };
  });
}

export function CoinBurst({ coins, visible, multiplier = 1 }) {
  // Generate spark positions once per mount (stable across re-renders)
  const sparks = useMemo(generateSparks, []);

  return (
    <div
      aria-live="polite"
      aria-atomic="true"
      style={{
        position: 'fixed',
        bottom: '110px',
        right: '32px',
        zIndex: 2147483647,
        opacity: visible ? 1 : 0,
        transform: visible
          ? 'translateY(0px) scale(1)'
          : 'translateY(12px) scale(0.8)',
        transition: 'opacity 0.3s ease, transform 0.3s cubic-bezier(0.34,1.56,0.64,1)',
        pointerEvents: 'none',
      }}
    >
      {/* Spark particles */}
      {visible && sparks.map((s) => (
        <div
          key={s.id}
          style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            width: s.size,
            height: s.size,
            borderRadius: '50%',
            background: s.color,
            boxShadow: `0 0 4px ${s.color}`,
            '--tx': s.tx,
            '--ty': s.ty,
            animation: `sparkPop 0.65s ease-out ${s.delay} forwards`,
          }}
        />
      ))}

      {/* Coin pill */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: '6px',
        background: 'linear-gradient(135deg, #5a2a00, #a85000)',
        border: '2px solid #ffe566',
        borderRadius: '20px',
        padding: '5px 14px 5px 8px',
        boxShadow: '0 0 24px rgba(255,210,0,0.7)',
      }}>
        <SpinningCoin size={22} delay={0} />
        <span style={{
          fontFamily: '"Courier New", monospace',
          fontSize: '15px',
          fontWeight: 'bold',
          color: '#ffe566',
          textShadow: '0 0 8px rgba(255,210,0,1)',
          userSelect: 'none',
        }}>
          +{coins}{multiplier > 1 ? ` ×${multiplier}` : ''}
        </span>
      </div>
    </div>
  );
}
