/**
 * Badge UI components — all pure display.
 * BadgeItem     — single badge tile with React-controlled tooltip
 * BadgeButton   — header trigger button (uses theme-btn class)
 * BadgePanel    — full badge grid modal (rendered at root to escape backdrop-filter)
 * BadgeToast    — slide-down unlock notification
 */

import React, { useState } from 'react';
import { getUnlockedBadges, getLevelInfo } from '../utils/gamification';
import { BADGES } from '../constants/gamification';

// ─── BadgeItem ────────────────────────────────────────────────

function BadgeItem({ badge, earned }) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        position: 'relative',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '4px',
        padding: '10px 4px',
        borderRadius: '10px',
        background: earned ? 'rgba(0,200,224,0.22)' : 'rgba(255,255,255,0.04)',
        border: `1px solid ${earned ? '#00c8e0' : 'rgba(255,255,255,0.10)'}`,
        opacity: earned ? 1 : 0.38,
        filter: earned ? 'none' : 'grayscale(1)',
        transition: 'opacity 0.2s, box-shadow 0.2s',
        boxShadow: earned ? '0 0 10px rgba(0,200,224,0.28)' : 'none',
        cursor: 'default',
      }}
    >
      <span style={{ fontSize: '22px', lineHeight: 1 }}>{badge.icon}</span>
      <span style={{
        fontSize: '8px',
        textAlign: 'center',
        color: earned ? '#a8e4f0' : '#6a9aaf',
        lineHeight: 1.3,
        fontWeight: earned ? '600' : '400',
      }}>
        {badge.name}
      </span>

      {/* Tooltip — rendered inline, never clipped by overflow:hidden parents */}
      {hovered && (
        <div style={{
          position: 'absolute',
          bottom: 'calc(100% + 8px)',
          left: '50%',
          transform: 'translateX(-50%)',
          background: '#041e30',
          border: '1px solid #00c8e0',
          borderRadius: '8px',
          padding: '7px 11px',
          whiteSpace: 'nowrap',
          zIndex: 2147483647,
          pointerEvents: 'none',
          boxShadow: '0 4px 20px rgba(0,0,0,0.85)',
        }}>
          <div style={{ fontSize: '11px', fontWeight: '700', color: '#fff', marginBottom: '3px' }}>
            {badge.name}
          </div>
          <div style={{ fontSize: '10px', color: '#a8e4f0' }}>
            {badge.desc}
          </div>
          {/* Arrow */}
          <div style={{
            position: 'absolute',
            top: '100%',
            left: '50%',
            transform: 'translateX(-50%)',
            width: 0,
            height: 0,
            borderLeft: '5px solid transparent',
            borderRight: '5px solid transparent',
            borderTop: '5px solid #00c8e0',
          }} />
        </div>
      )}
    </div>
  );
}

// ─── BadgeButton ──────────────────────────────────────────────

export function BadgeButton({ stats, onClick }) {
  const unlocked = getUnlockedBadges(stats);
  return (
    <button
      onClick={onClick}
      className="theme-btn px-3 py-1.5 rounded-full text-xs font-display font-600 tracking-wide"
      aria-label={`Badges: ${unlocked.length} of ${BADGES.length} unlocked`}
    >
      🎖️ {unlocked.length}/{BADGES.length}
    </button>
  );
}

// ─── BadgePanel ───────────────────────────────────────────────

export function BadgePanel({ stats, open, onClose }) {
  const unlocked = getUnlockedBadges(stats);
  if (!open) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        style={{
          position: 'fixed',
          inset: 0,
          zIndex: 2147483645,
          background: 'rgba(0,0,0,0.55)',
        }}
      />

      {/* Panel */}
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Badges"
        style={{
          position: 'fixed',
          top: '80px',
          right: '24px',
          width: '280px',
          background: '#0d3348',
          border: '2px solid #00c8e0',
          borderRadius: '16px',
          padding: '16px',
          zIndex: 2147483647,
          boxShadow: '0 0 0 1px #00c8e0, 0 0 40px rgba(0,200,224,0.55), 0 16px 60px rgba(0,0,0,0.9)',
        }}
      >
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '12px',
        }}>
          <span style={{ fontSize: '14px', fontWeight: '700', color: '#fff' }}>
            🎖️ Badges
          </span>
          <span style={{ fontSize: '11px', color: '#00c8e0' }}>
            {unlocked.length}/{BADGES.length} unlocked
          </span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px' }}>
          {BADGES.map((badge) => (
            <BadgeItem
              key={badge.id}
              badge={badge}
              earned={badge.condition(stats)}
            />
          ))}
        </div>

        <div style={{
          marginTop: '12px',
          paddingTop: '10px',
          borderTop: '1px solid rgba(0,200,224,0.18)',
          fontSize: '10px',
          color: '#5aaabf',
          textAlign: 'center',
        }}>
          Hover badges to see unlock conditions
        </div>
      </div>
    </>
  );
}

// ─── BadgeToast ───────────────────────────────────────────────

export function BadgeToast({ badge, visible }) {
  if (!badge) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      style={{
        position: 'fixed',
        top: '24px',
        left: '50%',
        zIndex: 2147483647,
        transform: `translateX(-50%) translateY(${visible ? '0px' : '-80px'})`,
        background: '#0d3348',
        border: '2px solid #00c8e0',
        borderRadius: '16px',
        padding: '14px 22px',
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        opacity: visible ? 1 : 0,
        transition: 'opacity 0.4s ease, transform 0.4s cubic-bezier(0.34,1.56,0.64,1)',
        boxShadow: '0 0 30px rgba(0,200,224,0.5), 0 8px 32px rgba(0,0,0,0.9)',
        pointerEvents: 'none',
      }}
    >
      <span style={{ fontSize: '32px', lineHeight: 1 }}>{badge.icon}</span>
      <div>
        <div style={{ fontSize: '10px', color: '#00c8e0', fontWeight: '700', letterSpacing: '1px' }}>
          BADGE UNLOCKED
        </div>
        <div style={{ fontSize: '15px', color: '#fff', fontWeight: '700' }}>
          {badge.name}
        </div>
        <div style={{ fontSize: '11px', color: '#a8e4f0' }}>
          {badge.desc}
        </div>
      </div>
    </div>
  );
}
