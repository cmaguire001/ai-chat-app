/**
 * ThemeSelector — theme switcher with unlock system.
 * Locked themes show a tooltip explaining how to unlock them.
 * Farmer theme unlocks after FARMER_THEME_UNLOCK_AT messages.
 */

import React, { useState, useRef, useEffect } from 'react';
import { THEMES, FARMER_THEME_UNLOCK_AT } from '../gamification/constants/gamification';

// ─── LockedThemeTooltip ───────────────────────────────────────

function LockedThemeTooltip({ theme, totalMessages, anchorRef }) {
  const remaining = Math.max(0, theme.unlockMessages - totalMessages);

  return (
    <div style={{
      position: 'fixed',
      zIndex: 2147483647,
      pointerEvents: 'none',
      background: '#1a1a2e',
      border: '1.5px solid #f5a623',
      borderRadius: '10px',
      padding: '8px 13px',
      boxShadow: '0 4px 20px rgba(0,0,0,0.7)',
      whiteSpace: 'nowrap',
      top: anchorRef.current
        ? anchorRef.current.getBoundingClientRect().bottom + 8
        : 60,
      left: anchorRef.current
        ? anchorRef.current.getBoundingClientRect().left + anchorRef.current.offsetWidth / 2
        : '50%',
      transform: 'translateX(-50%)',
    }}>
      <div style={{ fontSize: '11px', fontWeight: '700', color: '#f5a623', marginBottom: '2px' }}>
        🔒 Locked
      </div>
      <div style={{ fontSize: '10px', color: '#ccc' }}>
        {remaining === 0
          ? 'Unlocking…'
          : `${remaining} more message${remaining === 1 ? '' : 's'} to unlock 🌾 Farmer`}
      </div>
      {/* Arrow */}
      <div style={{
        position: 'absolute',
        bottom: '100%',
        left: '50%',
        transform: 'translateX(-50%)',
        width: 0, height: 0,
        borderLeft: '5px solid transparent',
        borderRight: '5px solid transparent',
        borderBottom: '5px solid #f5a623',
      }} />
    </div>
  );
}

// ─── ThemeSelector ────────────────────────────────────────────

export default function ThemeSelector({ theme, setTheme, totalMessages = 0 }) {
  const [hoveredLockedId, setHoveredLockedId] = useState(null);
  const buttonRefs = useRef({});

  const isUnlocked = (t) => !t.locked || totalMessages >= t.unlockMessages;
  const hoveredTheme = THEMES.find((t) => t.id === hoveredLockedId);

  return (
    <>
      <div className="flex gap-2 flex-wrap" style={{ alignItems: 'center' }}>
        {THEMES.map((t) => {
          const unlocked = isUnlocked(t);
          return (
            <button
              key={t.id}
              ref={(el) => { buttonRefs.current[t.id] = el; }}
              onClick={() => unlocked && setTheme(t.id)}
              onMouseEnter={() => !unlocked && setHoveredLockedId(t.id)}
              onMouseLeave={() => setHoveredLockedId(null)}
              className={`theme-btn px-3 py-1.5 rounded-full text-xs font-display font-600 tracking-wide ${
                theme === t.id ? 'active' : ''
              }`}
              style={{
                opacity: unlocked ? 1 : 0.5,
                cursor: unlocked ? 'pointer' : 'not-allowed',
                position: 'relative',
              }}
              aria-disabled={!unlocked}
              title={unlocked ? undefined : `Unlock after ${t.unlockMessages} messages`}
            >
              {!unlocked && (
                <span style={{ marginRight: '3px', fontSize: '10px' }}>🔒</span>
              )}
              {t.label}
            </button>
          );
        })}
      </div>

      {/* Tooltip rendered outside — not clipped by any parent overflow */}
      {hoveredTheme && hoveredLockedId && (
        <LockedThemeTooltip
          theme={hoveredTheme}
          totalMessages={totalMessages}
          anchorRef={{ current: buttonRefs.current[hoveredLockedId] }}
        />
      )}
    </>
  );
}
