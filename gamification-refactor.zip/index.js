/**
 * Gamification.jsx
 * ─────────────────────────────────────────────────────────────
 * Single import point for all gamification UI + logic.
 * index.jsx should import everything from here.
 *
 * Architecture notes:
 *  - Constants live in constants/gamification.js  (never mutated)
 *  - Pure functions live in utils/gamification.js  (easily testable)
 *  - All state lives in hooks/useGameStats.js       (one source of truth)
 *  - UI components are pure — no internal state except local UI (hover, etc)
 *  - BadgePanel + CoinBurst are rendered at the React root to escape
 *    backdrop-filter stacking contexts
 */

// ── Re-exports ────────────────────────────────────────────────

export { useGameStats }       from './hooks/useGameStats';
export { getLevelInfo }       from './utils/gamification';
export { BADGES, THEMES, LEVELS, FARMER_THEME_UNLOCK_AT } from './constants/gamification';

export { CoinBar }            from './components/CoinBar';
export { CoinBurst }          from './components/CoinBurst';
export { BadgeButton, BadgePanel, BadgeToast } from './components/Badges';
