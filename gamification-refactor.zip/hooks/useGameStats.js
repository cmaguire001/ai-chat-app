/**
 * useGameStats — owns all gamification state and side-effects.
 * Components receive data + callbacks; they never mutate state directly.
 */

import { useState, useCallback, useRef } from 'react';
import {
  calculateCoinsEarned,
  deriveNextStats,
  getMultiplier,
  getNewlyUnlockedBadges,
} from '../utils/gamification';
import { BADGES } from '../constants/gamification';

const INITIAL_STATS = {
  totalCoins:    0,
  totalMessages: 0,
  level:         1,
  unlockedBadgeIds: [],
};

/**
 * @returns {{
 *   stats: object,
 *   multiplier: number,
 *   coinBurst: { visible: boolean, amount: number },
 *   badgeToast: { visible: boolean, badge: object|null },
 *   onMessageSent: () => void,
 * }}
 */
export function useGameStats() {
  const [stats, setStats]           = useState(INITIAL_STATS);
  const [multiplier, setMultiplier] = useState(1);
  const [coinBurst, setCoinBurst]   = useState({ visible: false, amount: 0 });
  const [badgeToast, setBadgeToast] = useState({ visible: false, badge: null });

  // Refs to avoid stale closures in timeouts
  const coinBurstTimerRef  = useRef(null);
  const badgeToastTimerRef = useRef(null);

  const showCoinBurst = useCallback((amount) => {
    clearTimeout(coinBurstTimerRef.current);
    setCoinBurst({ visible: true, amount });
    coinBurstTimerRef.current = setTimeout(
      () => setCoinBurst((prev) => ({ ...prev, visible: false })),
      1800
    );
  }, []);

  const showBadgeToast = useCallback((badge) => {
    clearTimeout(badgeToastTimerRef.current);
    // Small delay so it doesn't compete with coin burst animation
    badgeToastTimerRef.current = setTimeout(() => {
      setBadgeToast({ visible: true, badge });
      badgeToastTimerRef.current = setTimeout(
        () => setBadgeToast({ visible: false, badge }),
        3000
      );
    }, 600);
  }, []);

  /**
   * Call this exactly once per message the user sends.
   * Handles coin calculation, stat update, badge checks, and UI feedback.
   */
  const onMessageSent = useCallback(() => {
    setStats((prevStats) => {
      // 1. Calculate new multiplier based on NEXT message count
      const nextMessageCount = prevStats.totalMessages + 1;
      const newMultiplier    = getMultiplier(nextMessageCount);
      setMultiplier(newMultiplier);

      // 2. Calculate coins
      const coinsEarned = calculateCoinsEarned(newMultiplier);

      // 3. Derive full new stats
      const newStats = deriveNextStats(prevStats, coinsEarned);

      // 4. Check for new badges
      const newBadges = getNewlyUnlockedBadges(prevStats.unlockedBadgeIds, newStats);
      newStats.unlockedBadgeIds = [
        ...prevStats.unlockedBadgeIds,
        ...newBadges.map((b) => b.id),
      ];

      // 5. Trigger UI feedback (outside setState to avoid batching issues)
      setTimeout(() => {
        showCoinBurst(coinsEarned);
        if (newBadges.length > 0) {
          showBadgeToast(newBadges[0]);
        }
      }, 0);

      return newStats;
    });
  }, [showCoinBurst, showBadgeToast]);

  return {
    stats,
    multiplier,
    coinBurst,
    badgeToast,
    onMessageSent,
  };
}
